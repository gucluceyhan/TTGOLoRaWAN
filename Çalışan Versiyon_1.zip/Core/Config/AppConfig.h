#ifndef APP_CONFIG_H
#define APP_CONFIG_H

#include <Arduino.h>
#include <lmic.h>
#include <hal/hal.h>
#include <SPI.h>

// Kullanıcı tarafından belirtilen DEVEUI, APPEUI ve APPKEY değerleri
// NOT: LMIC kütüphanesi için bu değerler LSB formatında olmalıdır
static const u1_t PROGMEM DEVEUI[8] = { 0xFF, 0xFE, 0x00, 0xD3, 0xA1, 0x2F, 0x2B, 0x14 }; // LSB formatında
static const u1_t PROGMEM APPEUI[8] = { 0x70, 0xB3, 0xD5, 0x55, 0x39, 0x37, 0xaf, 0x90 }; // LSB formatında
static const u1_t PROGMEM APPKEY[16] = { 0x4e, 0xf4, 0xd7, 0x33, 0x55, 0x39, 0x37, 0xaf, 0x90, 0xd7, 0x15, 0x98, 0x3f, 0xb5, 0x11, 0x27 }; // LSB formatında

// TTGO LoRa32 V2.1 için pin tanımları
#define LORA_SCK     5    // GPIO5  - SX1276 SCK
#define LORA_MISO    19   // GPIO19 - SX1276 MISO
#define LORA_MOSI    27   // GPIO27 - SX1276 MOSI
#define LORA_CS      18   // GPIO18 - SX1276 CS
#define LORA_RST     14   // GPIO14 - SX1276 RESET
#define LORA_IRQ     26   // GPIO26 - SX1276 IRQ (interrupt request)

// LMIC_DEBUG_LEVEL değeri (0: devre dışı, 1: hatalar, 2: bilgi)
#define LORA_DEBUG_LEVEL 1

// LMIC kütüphanesi tarafından kullanılan geri çağırma fonksiyonları için prototip tanımları
void os_getArtEui(u1_t* buf);
void os_getDevEui(u1_t* buf);
void os_getDevKey(u1_t* buf);

#endif // APP_CONFIG_H 